package com.ga.android.myapplication;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by wanmac on 7/26/16.
 */
public class VHolderItemDetail extends RecyclerView.ViewHolder {
    public VHolderItemDetail(View itemView) {
        super(itemView);
    }
}
